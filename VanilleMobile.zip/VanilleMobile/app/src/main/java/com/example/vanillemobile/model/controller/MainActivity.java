package com.example.vanillemobile.model.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.vanillemobile.R;
import com.example.vanillemobile.model.Commande;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //
        Commande commandeEnCours = Commande.getInstance();
        //
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        //
        String formatteDate = df.format(commandeEnCours.getDateCommande());
        //
        Toast toast =  Toast.makeText(getApplicationContext(), "Affichage test de la commande"
                +formatteDate+ "montant de la commande" +String.valueOf(commandeEnCours.getTotalCommande()),Toast.LENGTH_LONG);

        toast.show();
    }

}