package com.example.vanillemobile.model.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.vanillemobile.R;
import com.example.vanillemobile.model.Catalogue;
import com.example.vanillemobile.model.Categorie;
import com.example.vanillemobile.model.Commande;
import com.example.vanillemobile.model.Produit;

import java.time.LocalDate;

public class ProduitActivity extends AppCompatActivity {

    private EditText editQte;
    private Commande commandeEnCours;
    private Produit produitSelectionne;
    private Button btnCalculer;
    private Button btnAjouter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produit);
        init();
    }
    private void init(){
        editQte = findViewById(R.id.Produit_editQte);
        commandeEnCours = Commande.getInstance();
        Categorie chocolats = new Categorie("cho", "Chocolats");
        produitSelectionne = new Produit("BOO3", "Bonbons chocolats Lot 3 Kg", "", (float)3.0,chocolats );
        textPU.setText(String.valueOf(produitSelectionne.getPrixActuel(LocalDate.now())));
        btnCalculer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int qte;
                float prix;
                qte = Integer.parseInt(editQte.getText().toString());
                prix = Float.parseFloat(textPU.getText().toString());
                textTotalC.setText(String.valueOf(qte*prix));
            }
        });

        btnAjouter.setOnClickListener(new View.OnClickListener()) {
            @Override
            public void onClick(View view){
                int qte = Integer.parseInt(editQte.getText().toString());
            }
        }
    }
}