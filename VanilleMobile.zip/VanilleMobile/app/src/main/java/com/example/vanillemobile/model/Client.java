package com.example.vanillemobile.model;

public class Client {

    private String nomClient;
    private String prenomClient;
    private String adresseClient;
    private String cpClient;
    private String villeClient;
    private String mailClient;


    /**
     *
     * @param nomClient
     * @param prenomClient
     * @param adresseClient
     * @param cpClient
     * @param villeClient
     * @param mailClient
     */
    public Client(String nomClient, String prenomClient, String adresseClient, String cpClient, String villeClient, String mailClient) {
        this.nomClient = nomClient;
        this.prenomClient = prenomClient;
        this.adresseClient = adresseClient;
        this.cpClient = cpClient;
        this.villeClient = villeClient;
        this.mailClient = mailClient;
    }
}