package com.example.vanillemobile.model.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.vanillemobile.R;
import com.example.vanillemobile.model.Client;
import com.example.vanillemobile.model.Commande;

public class FactureActivity extends AppCompatActivity {

    private TextView txtMontant;
    private EditText editNom;
    private EditText editPrenom;
    private EditText editAdresse;
    private EditText editCP;
    private EditText editVille;
    private EditText editMail;
    private Button bt_envoyer;
    private Button bt_annuler;
    private Commande commandeEnCours;


    private void init(){
        editAdresse = findViewById(R.id.editAdresse);
        editCP = findViewById(R.id.editCP);
        editMail = findViewById(R.id.editMail);
        editNom = findViewById(R.id.editNom);
        editPrenom = findViewById(R.id.editPrenom);
        editVille = findViewById(R.id.editVille);
        txtMontant = findViewById(R.id.txtMontant);
        bt_envoyer = findViewById(R.id.bt_Envoyer);
        commandeEnCours = Commande.getInstance();
        txtMontant.setText(commandeEnCours.getTotalCommande());

        bt_envoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Création d'un client
                Client client = new Client(editNom.getText().toString(), editPrenom.getText().toString(), editAdresse.getText().toString(), editCP.getText().toString(), editVille.getText().toString(), editMail.getText().toString());

                //Ajout du client à la commande
                commandeEnCours.leClient = client;

                Toast.makeText(view.getContext(), "Votre commande d'un montant de " +txtMontant.getText()+
                        " a bien été envoyée ! Vous recevrez un mail de confirmation à l'adresse mail suivante : "+editMail.getText().toString(), Toast.LENGTH_SHORT).show();
                Log.i("envoyer","onClick "+ commandeEnCours.getLeClient().toString());
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facture2);
        init();
    }
}